import React from 'react'

export const chat = () => {
  return (
    <div>chat</div>
  )
}

export default chat;
### Backend(Flask)
1. User Authentication
2. Crud operations on FAQ (End-points given)


### Frontend(React)
1. Login page
2. Home page
3. Chatbot page (Pending)
4. Translator page
5. Faq page
6. About page



### Sample user to login
email = jane.doe@example.com
password = securepassword